function btns() {
    document.getElementById("showbtn").classList.toggle("active");
    console.log("hell")
}