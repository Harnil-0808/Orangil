  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
  import { getAuth,signInWithEmailAndPassword, } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyDyufC_JjKVUNOY21UM75j_nNVa9L6DojY",
    authDomain: "orangil.firebaseapp.com",
    projectId: "orangil",
    storageBucket: "orangil.appspot.com",
    messagingSenderId: "334238748755",
    appId: "1:334238748755:web:0bda6b94dfbbf1cd86b6a6"
  };

  const app = initializeApp(firebaseConfig);
  const auth = getAuth()


var email = document.getElementById("email");
var password = document.getElementById("password");

window.login= function(e) {
    e.preventDefault();
    var obj = {
      email: email.value,
      password: password.value,
    };
  
    signInWithEmailAndPassword(auth, obj.email, obj.password)
      .then(function (success) {
        alert("logined Successfully")
        var aaaa =  (success.user.uid);
        localStorage.setItem("uid",aaaa)
        console.log(aaaa)
        
        
        
        window.location.replace('homepage.html')
       // localStorage.setItem(success,user,uid)
        
      })
      .catch(function (err) {
        alert("login error"+err);
      });
  
    console.log(obj);
  }